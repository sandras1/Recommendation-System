<?php

return [
    'name' => 'IPFilter',
];
