<?php

return [
    'name' => 'Subscriber',
];
