<?php

return [
    'name' => 'Captcha',
];
