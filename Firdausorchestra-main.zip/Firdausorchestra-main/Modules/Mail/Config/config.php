<?php

return [
    'name' => 'Mail',
];
