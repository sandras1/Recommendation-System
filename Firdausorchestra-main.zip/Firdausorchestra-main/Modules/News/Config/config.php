<?php

return [
    'name' => 'News',
];
