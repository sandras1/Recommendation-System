<?php

return [
    'name' => 'Page',
];
