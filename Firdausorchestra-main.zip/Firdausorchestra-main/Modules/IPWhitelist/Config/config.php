<?php

return [
    'name' => 'IPWhitelist',
];
