<?php

return [
    'name' => 'General',
];
