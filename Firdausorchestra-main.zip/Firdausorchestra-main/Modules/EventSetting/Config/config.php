<?php

return [
    'name' => 'EventSetting',
];
